import App from "./pages/app.js";
import { initRouter } from "./routes/routes.js";
import "../styles/styles.css";

document.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");
  const currentHash = window.location.hash;

  // Jika belum login dan sedang di root, redirect ke login
  if (!token && (!currentHash || currentHash === "#/" || currentHash === "#")) {
    window.location.hash = "#/login";
  }

  const app = new App({
    navigationDrawer: document.querySelector("#navigation-drawer"),
    drawerButton: document.querySelector("#drawer-button"),
    content: document.querySelector("#main"),
  });

  // Pastikan render halaman setelah hashchange
  document.addEventListener("rerender", () => {
    app.renderPage();
  });

  initRouter(); // akan trigger rerender pertama
});
